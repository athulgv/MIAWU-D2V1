set_family {IGLOO2}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\component\work\TOP\OSC_0\TOP_OSC_0_OSC.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\clv_div.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\D_3_23Feb2019.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\f1_input.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\f3_f4_input.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\f9_input.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\input_faults.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\fault_prss_13march19.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\PE_3_23Feb2019.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\andgate_1.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\stopcom.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\D_FF.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\switchcheck.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\spi.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\hdl\main_PE_D_3_23Feb2019.vhd}
read_vhdl -mode vhdl_2008 {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\component\work\TOP\TOP.vhd}
set_top_level {TOP}
map_netlist
read_sdc {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\constraint\user.sdc}
check_constraints {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\constraint\synthesis_sdc_errors.log}
write_fdc {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\designer\TOP\synthesis.fdc}
