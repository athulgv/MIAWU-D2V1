open_project -project {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\designer\TOP\TOP_fp\TOP.pro}
enable_device -name {M2GL005} -enable 1
set_programming_file -name {M2GL005} -file {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\designer\TOP\TOP.ppd}
set_programming_action -action {PROGRAM} -name {M2GL005} 
run_selected_actions
save_project
close_project
