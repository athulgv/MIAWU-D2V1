probe \
    -desdir {F:\SYSTEMS AIDS\Miawu\UPGRADATION 2\Miawu_UPG_23-06-2021_V1\designer\TOP} \
    -design TOP \
    -fam IGLOO2 \
    -die PA4MGL500 \
    -pkg tq144 \
    -use_mvn_pdc 0  \
    -use_last_placement 0 