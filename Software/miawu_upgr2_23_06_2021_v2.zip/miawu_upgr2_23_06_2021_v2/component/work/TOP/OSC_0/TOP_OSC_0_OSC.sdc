set_component TOP_OSC_0_OSC
# Microsemi Corp.
# Date: 2021-Jun-21 12:22:25
#

create_clock -ignore_errors -period 31250 [ get_pins { I_XTLOSC/CLKOUT } ]
