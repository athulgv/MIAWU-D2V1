# Written by Synplify Pro version mapact2018q4p1, Build 026R. Synopsys Run ID: sid1624430158 
# Top Level Design Parameters 

# Clocks 
create_clock -period 31250.000 -waveform {0.000 15625.000} -name {XTL} [get_ports {XTL}] 
create_clock -period 10.000 -waveform {0.000 5.000} -name {clkdiv|a2_inferred_clock} [get_pins {clkdiv_0/a2/Q}] 
create_clock -period 10.000 -waveform {0.000 5.000} -name {clkdiv|a1_inferred_clock} [get_pins {clkdiv_0/a1/Q}] 
create_clock -period 10.000 -waveform {0.000 5.000} -name {TOP|RDY} [get_ports {RDY}] 

# Virtual Clocks 

# Generated Clocks 

# Paths Between Clocks 

# Multicycle Constraints 

# Point-to-point Delay Constraints 

# False Path Constraints 

# Output Load Constraints 

# Driving Cell Constraints 

# Input Delay Constraints 

# Output Delay Constraints 

# Wire Loads 

# Other Constraints 

# syn_hier Attributes 

# set_case Attributes 

# Clock Delay Constraints 
set_clock_groups -asynchronous -group [get_clocks {clkdiv|a2_inferred_clock}]
set_clock_groups -asynchronous -group [get_clocks {clkdiv|a1_inferred_clock}]
set_clock_groups -asynchronous -group [get_clocks {TOP|RDY}]
set_clock_groups -asynchronous -group [get_clocks {TOP_OSC_0_OSC|N_XTLOSC_CLKOUT_inferred_clock}]

# syn_mode Attributes 

# Cells 

# Port DRC Rules 

# Input Transition Constraints 

# Unused constraints (intentionally commented out) 

# Non-forward-annotatable constraints (intentionally commented out) 

# Block Path constraints 

