project -load "F:/SYSTEMS AIDS/Miawu/UPGRADATION 2/Miawu_UPG_23-06-2021_V1/synthesis/TOP_syn.prj"
project -run
project -save
